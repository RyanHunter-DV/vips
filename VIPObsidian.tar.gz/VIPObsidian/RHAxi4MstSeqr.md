typical sequencer for driving master sequences
# Source Code
**sequencer** RHAxi4MstSeqr
