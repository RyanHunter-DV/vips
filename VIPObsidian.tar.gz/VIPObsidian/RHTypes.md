# Source Code

## ResetEnum
**raw**
```
typedef enum logic {
	RHResetUnknow   = 'bx,
	RHResetActive   = 'b1,
	RHResetInactive = 'b0
} RHResetState_enum;
```