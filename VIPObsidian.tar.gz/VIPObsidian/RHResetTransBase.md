
# Source Code
resest enum declared in [[RHTypes#ResetEnum]]
**transaction** RHResetTransBase
**field**
```
RHResetState_enum state;
```